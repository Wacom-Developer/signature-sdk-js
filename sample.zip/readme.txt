
Wacom Ink SDK for signature - JavaScript

Version 1.0.0

----------------------------------------------------------------------------------------------------------------
About

Wacom Ink SDK for signature - JavaScript provides the documentation and tools to create signature enabled 
applications using STU and Wintab devices.

For further details on using the SDK see https://developer-docs.wacom.com
Navigate to: Wacom Ink SDK for signature
References are included to the SDK sample code on GitHub: https://github.com/Wacom-Developer/Wacom-Developer-Welcome-Page



----------------------------------------------------------------------------------------------------------------
File Contents
├───common	- contains the files to accommodate the SDK in this sample. 
├───simple	- contains the sample's .html page and .js for the site.  
└───readme.txt	- this readme file          
     
----------------------------------------------------------------------------------------------------------------
Version History

  Release 1.0.0  19-Nov-2021
    - Initial release

    
Copyright © 2021 Wacom, Co., Ltd. All Rights Reserved.
